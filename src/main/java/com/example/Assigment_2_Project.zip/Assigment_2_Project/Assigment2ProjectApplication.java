package com.example.Assigment_2_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assigment2ProjectApplication {

	public static void main(String[] args) {

		SpringApplication.run(Assigment2ProjectApplication.class, args);
	}

}
